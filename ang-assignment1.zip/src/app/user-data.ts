export interface userData {
  name: string;
  designation: string;
  university: string;
  city: string;
  imgUrl: string;
}
